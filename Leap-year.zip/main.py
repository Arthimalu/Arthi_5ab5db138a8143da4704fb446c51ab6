import calendar
print(calendar.isleap(2016))
print(calendar.isleap(2000))
print(calendar.isleap(2100))